package com.manerajona.testcontainers.ports.output.gateway;

public record CardValidationResponse(boolean isValid) {
}