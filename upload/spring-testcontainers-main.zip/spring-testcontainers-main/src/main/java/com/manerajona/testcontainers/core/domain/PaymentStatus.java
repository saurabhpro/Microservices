package com.manerajona.testcontainers.core.domain;

public enum PaymentStatus {
    PENDING_VALIDATION, OK, ERROR
}