package com.manerajona.testcontainers.core.domain;

public enum PaymentMethod {
    CARD, CASH
}