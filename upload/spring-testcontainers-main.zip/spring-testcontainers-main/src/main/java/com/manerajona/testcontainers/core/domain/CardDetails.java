package com.manerajona.testcontainers.core.domain;

public record CardDetails(String number, int expDate, int cvc) {
}